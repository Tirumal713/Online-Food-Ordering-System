from django.db import models
from django.contrib.auth.models import User
from datetime import date

# Create your models here.



class City(models.Model):
	city_name=models.CharField(max_length=40)
	class Meta:
		db_table='city'
	def __str__(self):
	        return self.city_name

class Area(models.Model):
	area_name=models.CharField(max_length=40)
	pincode=models.BigIntegerField()
	city=models.ForeignKey(City,on_delete=models.CASCADE)
	class Meta:
		db_table='area'
	def __str__(self):
	        return self.area_name

class Admin(models.Model):
	username=models.CharField(max_length=30)
	password=models.CharField(max_length=8)
	user= models.OneToOneField(User,on_delete=models.CASCADE,default="")
	class Meta:
		db_table='admin'
		
    

	
                
class Customer(models.Model):
	c_name=models.CharField(max_length=30)
	email=models.EmailField(max_length=50)
	password=models.CharField(max_length=8)
	dob=models.DateField()
	contact=models.BigIntegerField()
	gender=models.CharField(max_length=8)
	address=models.TextField()
	reg_date=models.DateField(auto_now_add=True)
	city=models.ForeignKey(City,on_delete=models.CASCADE)
	area=models.ForeignKey(Area,on_delete=models.CASCADE)
	user= models.OneToOneField(User,on_delete=models.CASCADE,default="")
	class Meta:
		db_table='customer'
	def __str__(self):
	        return self.c_name

class Seller(models.Model):
	name=models.CharField(max_length=30)
	email=models.EmailField(max_length=30)
	password=models.CharField(max_length=50)
	contact=models.BigIntegerField()
	address=models.TextField()
	image = models.CharField(max_length=255,default="")
	city=models.ForeignKey(City,on_delete=models.CASCADE)
	area=models.ForeignKey(Area,on_delete=models.CASCADE)
	user= models.OneToOneField(User,on_delete=models.CASCADE,default="")
	class Meta:
		db_table='seller'
		
class Sub_category(models.Model):
    category_name=models.CharField(max_length=50)
    seller=models.ForeignKey(Seller,on_delete=models.CASCADE,default="")
    class Meta:
        db_table="sub_category"
    
class Add_fooditem(models.Model):
    name=models.CharField(max_length=40)
    price=models.BigIntegerField()
    image = models.CharField(max_length=255)
    Category=models.CharField(max_length=10, default="")
    sub_category=models.ForeignKey(Sub_category, on_delete=models.CASCADE, default="")
    quantity=models.IntegerField()
    description=models.TextField(default="")
    seller=models.ForeignKey(Seller,on_delete=models.CASCADE,default="")
    class Meta:
        db_table='add_fooditem'
    def __str__(self):
	        return self.name

class Feedback(models.Model):
	feedback=models.TextField()
	date=models.DateField(auto_now_add=True)
	rating=models.IntegerField()
	customer=models.ForeignKey(Customer,on_delete=models.CASCADE,default="")
	class Meta:
		db_table='feedback'


class Inquiry(models.Model):
	name=models.CharField(max_length=30)
	email=models.EmailField(max_length=50)
	contact=models.BigIntegerField()
	message=models.TextField()
	date=models.DateField(auto_now_add=True)
	customer=models.ForeignKey(Customer,on_delete=models.CASCADE,default="")
	class Meta:
		db_table='inquiry'
	def __str__(self):
		return self.name



class Cart(models.Model):
	quantity = models.BigIntegerField()
	price=models.DecimalField(max_digits=10,decimal_places=2)
	food_item = models.ForeignKey(Add_fooditem,on_delete=models.CASCADE)
	seller = models.ForeignKey(Seller,on_delete=models.CASCADE)
	customer = models.ForeignKey(Customer,on_delete=models.CASCADE)

	class Meta:
		db_table = 'cart'


class Order(models.Model):
    amount = models.DecimalField(max_digits = 10,decimal_places = 2)
    customer= models.ForeignKey(Customer, on_delete=models.CASCADE)
    seller= models.ForeignKey(Seller, on_delete=models.CASCADE)
    date    = models.DateField(default=date.today)
    status = models.CharField(max_length=100)

    class Meta:
        db_table = 'order'

class Order_details(models.Model):
    food_item = models.ForeignKey(Add_fooditem, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price  = models.DecimalField(max_digits = 10,decimal_places = 2)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    seller  = models.ForeignKey(Seller, on_delete=models.CASCADE)

    class Meta:
        db_table = 'Order_details'
	
    def __str__(self):
	    return self.name

class Payment_Details(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    payment_method = models.CharField(max_length=30)
    payment_id = models.TextField()
    signature = models.TextField()

    class Meta:
        db_table = 'Payment_Details'
  
	
class Billing(models.Model):
    name = models.CharField(max_length=50)
    address = models.TextField()
    email = models.CharField(max_length=50)
    pin = models.CharField(max_length=50)
    phone = models.BigIntegerField()
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    area = models.ForeignKey(Area, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    payment_details = models.ForeignKey(Payment_Details, on_delete=models.CASCADE)

    class Meta:
        db_table = 'billing'
    def __str__(self):
	    return self.name

class Shipping(models.Model):
    name = models.CharField(max_length=50)
    address = models.TextField()
    email = models.CharField(max_length=50)
    pin = models.CharField(max_length=50)
    phone = models.BigIntegerField()
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    area = models.ForeignKey(Area, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    payment_details = models.ForeignKey(Payment_Details, on_delete=models.CASCADE)

    class Meta:
        db_table = 'shipping'
	
    def __str__(self):
	    return self.name

