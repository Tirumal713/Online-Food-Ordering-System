from django.shortcuts import render, redirect
from seller.models import *
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib import auth, messages


# Create your views here.

def dashboard(request):
    context = {}
    return render(request, 'myadmin/dashboard.html', context)


def layout(request):
    context = {}
    return render(request, 'myadmin/common/layout.html', context)


def all_user(request):
    result = Customer.objects.all()
    context = {'result': result}
    return render(request, 'myadmin/all_user.html', context)


def all_user_detail(request, id):
    result = Customer.objects.get(pk=id)
    context = {'result': result}
    return render(request, 'myadmin/all_user_detail.html', context)


def all_seller(request):
    result = Seller.objects.all()
    context = {'result': result}
    return render(request, 'myadmin/all_seller.html', context)


def all_seller_detail(request, id):
    result = Seller.objects.get(pk=id)
    data = {'result': result}
    return render(request, 'myadmin/all_seller_details.html', data)


def all_feedback(request):
    result = Feedback.objects.all()
    context = {'result': result}
    return render(request, 'myadmin/all_feedback.html', context)


def all_inquiry(request):
    result = Inquiry.objects.all()
    context = {'result': result}
    return render(request, 'myadmin/all_inquiry.html', context)


def login(request):
    context = {}
    return render(request, 'myadmin/login.html', context)


def view_user(request):
    result = User.objects.all()
    context = {'User': result}
    return render(request, 'myadmin/view_user.html', context)

# def all_seller(request):
#     result=Seller.objects.all()
#     context = {'result':result}
#     return render(request,'myadmin/all_seller.html',context)


def login(request):
    return render(request, 'myadmin/login.html')


def login_check(request):
    username = request.POST['username']
    password = request.POST['password']
    result = auth.authenticate(request, username=username, password=password)
    if result is None:
        messages.error(
            request, "username or password is incorrect. Try again.")
        return redirect('/myadmin/')
    else:
        if Seller.objects.filter(user_id=result.id).exists():
            messages.error(
                request, "username or password is incorrect. Try again.")
            return redirect('/myadmin/')
        elif Customer.objects.filter(user_id=result.id).exists():
            messages.error(
                request, "username or password is incorrect. Try again.")
            return redirect('/myadmin/')
        else:
            auth.login(request, result)
            return redirect('/myadmin/dashboard')


def logout(request):
    auth.logout(request)
    return redirect('/customer/home')


# def login_check(request):
#     username = request.POST['email_username']
#     password = request.POST['password']

#     result = admin_register.objects.values_list('username')
#     result1 = admin_register.objects.values_list('password')

#     result1_list=list(result1)
#     result1_string=','.join(result1_list[0])

#     result_list=list(result)
#     result_string=','.join(result_list[0])


#     result2_user = admin_register.objects.values_list('username')
#     result2_pass = admin_register.objects.values_list('password')

#     result2_user_list=list(result2_user)
#     result2_user_string=','.join(result2_user_list[1])

#     result2_pass_list=list(result2_pass)
#     result2_pass_string=','.join(result2_pass_list[1])


#     result3_user = admin_register.objects.values_list('username')
#     result3_pass = admin_register.objects.values_list('password')

#     result3_user_list=list(result3_user)
#     result3_user_string=','.join(result3_user_list[2])

#     result3_pass_list=list(result3_pass)
#     result3_pass_string=','.join(result3_pass_list[2])


#     if ((result_string == username) and (result1_string == password)) or((result2_user_string == username) and (result2_pass_string == password)) or((result3_user_string == username) and (result3_pass_string == password)):
#         return redirect('/myadmin/dashboard')
#         # messages.success(request,"login succesfully..")
#     else:
#         messages.error(request,"username or password is incorrect. Try again.")
#         return redirect('/myadmin/')


# def read_user(request):
#     result=add_user.objects.all()
#     context={'result':result}
#     return render(request,'/all_user.html',context)
