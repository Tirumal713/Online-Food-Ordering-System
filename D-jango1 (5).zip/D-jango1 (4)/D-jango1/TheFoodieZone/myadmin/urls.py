"""TheFoodieZone URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from myadmin import views

urlpatterns = [
    path('dashboard', views.dashboard, name='dashboard'),
    path('layout', views.layout, name='layout'),

    path('all_user', views.all_user, name='all_user'),
    path('all_user_detail/<int:id>', views.all_user_detail, name='all_user_detail'),

    path('all_seller', views.all_seller, name='all_seller'),
    path('all_seller_details/<int:id>', views.all_seller_detail, name='all_seller_detail'),

    path('all_feedback', views.all_feedback, name='all_feedback'),

    path('all_inquiry', views.all_inquiry, name='all_inquiry'),

    # path('view_user', views.view_user, name='view_user'),
    
    path('', views.login, name='login'),
    path('login_check', views.login_check, name='login_check'),
    path('logout', views.logout, name='logout'),
]
